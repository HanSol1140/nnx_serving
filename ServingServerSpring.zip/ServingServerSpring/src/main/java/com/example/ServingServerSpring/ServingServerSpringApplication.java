package com.example.ServingServerSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServingServerSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServingServerSpringApplication.class, args);
	}

}
